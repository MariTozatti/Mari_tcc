<html>
    <head>
        <title>Aplicação</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="bootstrap-3.4.1-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-3.4.0.min.js" type="text/javascript"></script>
        <link href="css/login.css" rel="stylesheet" type="text/css"/>
        <style>
            body{
                background-image: url("img/fundo_login.png");
                background-attachment: fixed;
                background-size: cover;
            }     
            .icone{
                width: 150px;
                height: 150px;
                margin-left: 25%;
                margin-top: 3%;

            }
            .jumbotron{
                width: 400px;
                margin-top: 6%;
                margin-left: auto;
                margin-right: auto;
                background-color:rgba(237, 233, 221, 0.76);
                
            }
            .teste{
                margin-bottom: 0%;
            }
        </style>  
        <script>
            $(document).ready(function () {

                // Click event of the showPassword button
                $('#mostrarSenha').on('click', function () {

                    // Get the password field
                    var passwordField = $('#senha');

                    // Get the current type of the password field will be password or text
                    var passwordFieldType = passwordField.attr('type');

                    // Check to see if the type is a password field
                    if (passwordFieldType == 'password')
                    {
                        // Change the password field to text
                        passwordField.attr('type', 'text');
                    } else {
                        // If the password field type is not a password field then set it to password
                        passwordField.attr('type', 'password');
                    }
                });
            });
        </script>
    </head>
    <body>
        <form action="controller/cusuarios.php" method="POST">
            <div class="container">
                <div class="jumbotron" style="border-radius: 0px;">
                    <div class="row">
                        <center> <h3> Acesso ao Sistema </h3></center>
                        <img src="img/icone_login.png" alt="icone" class="icone"/>

                        <h4> Usuário: </h4>
                        <div class="form-group">
                            <input type="text" name="login" class="form-control" placeholder="Usuário"/>
                        </div>

                        <h4> Senha: </h4>
                        <div class="input-group form-group teste">
                            <input type="password" name="senha" id="senha" class="form-control" placeholder="Senha"/>
                            <span class="input-group-addon"><a class="glyphicon glyphicon-eye-open" id="mostrarSenha" href="#"></a></span>    
                        </div>
                        <div calss="frase" style="margin-left: 55%; margin-bottom: 3%;">Esqueceu sua senha?</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="index.php" class="form-control btn btn-primary">Entrar</a>
                            <!--<input type="submit" name="entrar" id="entrar" value="Entrar" class="form-control btn btn-primary"/>-->
                        </div>
                        <div class="col-md-6">
                            <input type="submit" name="cadastrar" id="entrar" value="Cadastra-se" class="form-control btn btn-primary"/> 
                        </div>                    
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>

