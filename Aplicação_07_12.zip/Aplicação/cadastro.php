<?php
include_once 'config/header.php';

include_once ('controller/cusuario.php');
include_once ('controller/ctopicos.php');
?>
<link href="css/cadastro.css" rel="stylesheet" type="text/css"/>
<form action="controller/cusuario.php" method="POST">
    
    <div class="container">
        <div class="caixa caixa2">
            <nav class="nav_tabs">
                <ul>
                    <li>
                        <input type="radio" id="tab1" class="rd_tab" name="tabs" checked>
                        <label for="tab1" class="tab_label">Usuários</label>
                        <div class="tab-content">
                            <h2>Cadastro de Usuários</h2>
                            <div class="row formularios">
                                <div class="form-group col-md-12">
                                    <label> Nome: </label>
                                    <input type="text" name="nome" class="form-control"
                                           placeholder="Nome completo" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label > Usuário de Login: </label>
                                    <input type="text" name="usuario" class="form-control"
                                           placeholder="Nome do usuário(login)" />
                                </div>
                                <div class="form-group col-md-6">
                                    <label > Senha: </label>
                                    <input type="text" name="senha" class="form-control"
                                           placeholder="Senha do usuário(login)" />
                                </div>
                            </div>
                            <div class="row botoes">
                                <div class="form-group col-md-12">
                                    <input type="submit" name="gravar" value="Gravar" class="btn btn-success">
                                    <input type="submit" name="excluir" value="Excluir" class="btn btn-danger">
                                </div>
                            </div>
                    </li>
<!--                    </form>
                    <form action="controller/ctopico.php" method="POST">-->
                    <li>
                        <input type="radio" name="tabs" class="rd_tab" id="tab2">
                        <label for="tab2" class="tab_label">Tópicos</label>
                        <div class="tab-content">
                            <h2>Cadastro de Tópicos</h2>
                            <div class="row formularios">
                                <div class="form-group col-md-3">
                                    <label > Ano: </label>
                                    <input type="text" name="ano" class="form-control"
                                           placeholder="Ano Referênte" />
                                </div>
                                <div class="form-group col-md-3">
                                    <label > Posição: </label>
                                    <input type="text" name="posicao" class="form-control"
                                           placeholder="Posição no Hanking" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label > Vulnerabilidade: </label>
                                    <input type="text" name="vulnerabilidade" class="form-control"
                                           placeholder="Nome da vulnerabilidade" />
                                </div>
                            </div>
                            <div class="row botoes">
                                <div class="form-group col-md-12">
                                    <input type="submit" name="gravar" value="Gravar" class="btn btn-success">
                                    <input type="submit" name="excluir" value="Excluir" class="btn btn-danger">
                                </div>
                            </div>
                        </div>
                    </li>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="rodape">
            <center><p>IFSP - VOTUPORANGA @2020</p></center>
        </div>

    </div>
</form>
</body>
</html>
