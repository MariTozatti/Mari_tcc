    <?php
include_once 'config/header.php';
?>
<link href="css/top10.css" rel="stylesheet" type="text/css"/>
        <div class="container">
            <div class="caixa caixa2">
                <nav class="nav_tabs">
                    <ul>
                        <li>
                            <input type="radio" id="tab1" class="rd_tab" name="tabs" checked>
                            <label for="tab1" class="tab_label">OWASP</label>
                            <div class="tab-content">
                                <h2 class="">O que é o OWASP?</h2>
                                
                                <p class="txt" style="text-indent: 4%; margin-top:3%"> 
                                    O Open Web Application Security Project ® (OWASP) é uma fundação sem fins lucrativos que 
                                    trabalha para melhorar a segurança do software. Por meio de projetos de software de código
                                    aberto liderados pela comunidade, centenas de capítulos locais em todo o mundo, dezenas de
                                    milhares de membros e conferências líderes de educação e treinamento, a Fundação OWASP é a
                                    fonte para desenvolvedores e tecnólogos protegerem a web. </p>

                                <p> Fonte: <a href="https://owasp.org/" target="_blank"> https://owasp.org/ </a> </p>
                                <h3 style="color: black">Quer saber quais são as Vulnerabilidades do ano? Vá para aba do menu chamada <a href="top10.php"> Top10 </a>.</h3>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="rodape">
                <center><p>IFSP - VOTUPORANGA @2020</p></center>
            </div>
        </div>
    </body>
</html>
