<?php
include_once 'config/header.php';
include_once('controller/ctopicos.php');
?>
<link href="css/top10.css" rel="stylesheet" type="text/css"/>
<form action="controller/ctopicos.php" method="POST">
    <div class="container">
        <div class="caixa caixa2">
            <nav class="nav_tabs">
                <ul>
                    <li>
                        <input type="radio" id="tab1" class="rd_tab" name="tabs" checked>
                        <label for="tab1" class="tab_label">Top 10 Vulnerabilidades</label>
                        <div class="tab-content">
                            <h2>Vulnerabilidades</h2>
                            <div class="row formularios">
                                <div class="form-group col-md-10">
                                    <label> Pesquisa: </label>
                                    <input type="text" name="pesquisa_top" class="form-control"
                                           placeholder="Pesquisa por data, posição ou nome" />
                                </div>
                                <div class="form-group col-md-2 botoes" style="margin-top:2.75%;">
                                    <input type="submit" name="localizar" value="Localizar" class="btn btn-primary">
                                </div>
                            </div>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Ano</th>
                                        <th scope="col">Posição</th>
                                        <th scope="col">Vulnerabilidade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>2020</td>
                                        <td>1°</td>
                                        <td>SQL Injection</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="rodape">
            <center><p>IFSP - VOTUPORANGA @2020</p></center>
        </div>

    </div>
</form>
</body>
</html>
