<?php
if(isset($_POST['usuario'])){    
    include_once 'login.php';
        header('location:../index.php');
}
?>
