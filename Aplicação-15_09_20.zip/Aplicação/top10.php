<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <script src="js/jquery-3.4.0.min.js" type="text/javascript"></script>
        <link href="bootstrap-3.4.1-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="bootstrap-3.4.1-dist/js/bootstrap.min.js" type="text/javascript"></script>

        <script src="js/jquery.mask.min.js" type="text/javascript"></script>

        <script src="js/jquery-ui.min.js" type="text/javascript"></script>
        <link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>

        <script src="js/validator.js" type="text/javascript"></script>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link href="css/top10.css" rel="stylesheet" type="text/css"/>
        <style>
            .icone_owasp_menu{
                height: 8%;
                width: 65%;
            }
            .glyphicon{
                font-size:25px;
                color:#FF6600;
            }
            .glyphicon:active{
                font-size:25px;
                color:#2aabd2;
            }
            a:hover{
                color: #23527c;
            }
        </style>
        <script>
            window.console = window.console || function (t) {};

            if (document.location.search.match(/type=embed/gi)) {
                window.parent.postMessage("resize", "*");
            }
        </script>
        <title> Aplicação </title>
    </head>
    <body translate="no">
        <nav class="sidebar-navigation">
            <ul>
                <li class="active">
                    <a href="index.php"><img src="img/owasp_icon.png" class="icone_owasp_menu"></a>
                    <span class="tooltip" style="margin-top: 0.5%;"> OWASP </span>          
                </li>
                <li class="active">   
                    <a href="top10.php"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></a>
                    <span class="tooltip" style="margin-top: 0.01%;">Top 10</span>
                </li>
                <li>
                    <a href="cadastro.php"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span></a>
                    <span class="tooltip" style="margin-top: 0.01%;">Cadastro</span>
                </li>
                <li>
                    <a href="login.php"><span class="glyphicon glyphicon-log-in" aria-hidden="true"></span></a>
                    <span class="tooltip" style="margin-top: 0.01%;">Entrar</span>
                </li>
                <li> 
                    <a href=""><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span></a>
                    <span class="tooltip">Log Out</span>
                </li>
            </ul>
        </nav>
        <script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-157cd5b220a5c80d4ff8e0e70ac069bffd87a61252088146915e8726e5d9f147.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script id="rendered-js">
            $('ul li').on('click', function () {
                $('li').removeClass('active');
                $(this).addClass('active');
            });
//# sourceURL=pen.js
        </script>
        <div class="container">
            <div class="caixa caixa2">
                <nav class="nav_tabs">
                    <ul>
                        <li>
                            <input type="radio" id="tab1" class="rd_tab" name="tabs" checked>
                            <label for="tab1" class="tab_label">Top 10 Vulnerabilidades</label>
                            <div class="tab-content">
                                <h2>Vulnerabilidades</h2>
                                <div class="row formularios">
                                    <div class="form-group col-md-10">
                                        <label> Pesquisa: </label>
                                        <input type="text" name="nome_pes" class="form-control"
                                               placeholder="Pesquisa por data, posição ou nome" />
                                    </div>
                                    <div class="form-group col-md-2 botoes" style="margin-top:2.75%;">
                                        <input type="submit" name="localizar" value="Localizar" class="btn btn-primary">
                                    </div>
                                </div>
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Ano</th>
                                            <th scope="col">Posição</th>
                                            <th scope="col">Vulnerabilidade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>2020</td>
                                            <td>1°</td>
                                            <td>SQL Injection</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="rodape">
                <center><p>IFSP - VOTUPORANGA @2020</p></center>
            </div>

        </div>
    </body>
</html>
